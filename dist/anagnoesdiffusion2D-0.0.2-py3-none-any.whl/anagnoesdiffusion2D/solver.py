from diffusion2d import solve
solve()